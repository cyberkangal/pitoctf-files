KUZey MÜZESİ — Kasa Koridoru

index.html dosyasını bir tarayıcıda aç. İnternet veya sunucu gerekmez.

Soru açıklaması:
Sen Kuzey Müzesi'nde gece vardiyasında çalışan bir müze görevlisisin. Değerli eserlerin asılları kasada tutuluyor; sergi salonunda güvenlik amacıyla hazırlanmış kopyalar sergileniyor. Gece biri kasaya girmeye çalıştı, fakat şifreyi art arda yanlış girince kasa koridorunun kapısı kilitlendi. Güvenlik amiri senden dahili portal kayıtlarını inceleyerek kapının dört haneli acil durum şifresini bulmanı istiyor.

Gönderim biçimi: pitoctf{kapışifresi}
