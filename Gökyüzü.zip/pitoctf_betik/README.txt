pitoCTF - Gökyüzünde ne oluyor?

Kategori: Betik / Misc

Soru açıklaması:
Gökyüzünde ne oluyor?

Dosya: gokyuzu.py
Flag formatı: pitoctf{...}
