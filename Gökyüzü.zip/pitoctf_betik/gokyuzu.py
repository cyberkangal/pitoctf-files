#!/usr/bin/env python3
# pitoCTF - gokyuzu
# Python 3.10+

import base64, zlib, hashlib

CONSTELLATIONS = {
    'ursa_minor': [7, 19, 3, 23, 11, 2, 29],
    'orion':      [4, 8, 15, 16, 23, 42],
    'lyra':       [12, 1, 18, 9, 5],
    'cygnus':     [3, 25, 7, 14, 21, 19],
}

# Gozlem kayitlari. Hepsi gercek olmak zorunda degil.
LOG = [
    'cGl0b2N0ZntmaWxfdWN1eW9yfQ==',
    'cGl0b2N0ZntheV9wZXluaXJ9',
    'cGl0b2N0Znt5aWxkaXpfZHVzdHV9',
    'cGl0b2N0ZntnZXplZ2VuX2thY2RpfQ==',
    'cGl0b2N0ZntheV9rYXlkYXNpfQ==',
    'cGl0b2N0Znt1eWR1X2ZvdG9ncmFmX2Nla3RpfQ==',
    'cGl0b2N0ZntidWx1dF9rb251c3R1fQ==',
    'cGl0b2N0Znt1Zm9fZ2VjdGl9',
]

# Teleskop tamponu. "Parlak" olan her sey yildiz degildir.
DUST = [
    'U0dWc2JHOGdWMjl5YkdRPQ==',
    'cGl0b2N0Znt5aWxkaXpfYmVuX2RlZ2lsaW19',
    'VEhJU19JU19OT1RfVEhFX0ZMQUc=',
    'cGl0b2N0ZntzYW1hbnlvbHVfZGVnaWx9',
    'ZUp3cnlDekpUeTVKcTA0RWdzb2pHM05TalN5c3lnYXhLdk9MYWdITGpBNDM=',
    'cGl0b2N0Zntnb2t5dXp1X2JvemR1bn0=',
]

# UTC saniyeleri: gozlem cihazinin saatinde bir sey ters.
TICKS = [23, 5, 17, 11, 2, 19, 7, 13]


def b64(s):
    try:
        return base64.b64decode(s).decode('utf-8')
    except Exception:
        return ''


def meteor(s):
    # Gosterisli ama anlamsiz bir yol.
    h = hashlib.sha256(s.encode()).hexdigest()
    return 'pitoctf{' + h[:16] + '}'


def telescope():
    print('[*] Teleskop kalibre ediliyor...')
    for i, x in enumerate(LOG):
        if i % 2 == 0:
            print('  ', b64(x))
        else:
            print('  ', meteor(x))


def horizon():
    # En parlak cisimleri secmek genellikle kotu fikirdir.
    return sorted(DUST, key=lambda x: sum(map(ord, x)), reverse=True)


def north_is_not_up(seq):
    # Cihaz kuzeyi 3 kademe kaymis kaydetmis.
    k = 3
    return seq[k:] + seq[:k]


def observer(seed):
    # Bir baska sahte dogrulama mekanizmasi.
    candidates = []
    for name, stars in CONSTELLATIONS.items():
        v = sum((i + 1) * x for i, x in enumerate(stars)) ^ seed
        candidates.append(f'pitoctf{{{name}_{v & 0xffff:04x}}}')
    return candidates


def zenith():
    # "Kutup yildizi sabittir." Sabit kalan indeksleri dusun.
    a = CONSTELLATIONS['ursa_minor']
    b = north_is_not_up(TICKS)
    return [i for i, (x, y) in enumerate(zip(a, b)) if (x ^ y) & 1 == 0]


def main():
    telescope()
    print('\n[*] Ufuk taraniyor...')
    for x in horizon()[:3]:
        print('  sinyal:', b64(x))

    print('\n[*] Otomatik cozum adaylari:')
    for x in observer(sum(TICKS)):
        print('  ', x)

    # Burada bilerek flag yazdirilmiyor.
    # Gozlemci, hangi verinin "dusmedigini" bulmali.
    idx = zenith()
    print('\n[*] Sabit noktalar:', idx)
    print('[!] Gozlem tamamlandi. Gokyuzunde ne oluyor?')

if __name__ == '__main__':
    main()
